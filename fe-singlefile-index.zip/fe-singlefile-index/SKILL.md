---
name: "fe-singlefile-index"
description: "将前端构建产物合并为单个 dist/index.html（内联 JS/CSS/可选资源）。当用户需要单文件部署/离线打开/合并到一个 HTML 时调用。"
---

# Frontend Singlefile Index

把一个前端项目的发布产物收敛为单个 `index.html`，用于：
- 直接双击打开（离线演示）
- 发送给别人一个文件就能跑
- 部署到任意静态托管（无需 assets 目录）

## 何时调用
- 用户说“把所有前端页面合并到 index.html”
- 用户说“我要单文件部署/单 HTML 产物/离线打开”
- 用户说“打包后只保留一个 HTML”

## 目标验收
- 生成 `dist/index.html`
- 默认：JS/CSS 内联进 `dist/index.html`
- 严格单文件模式：图片/字体等资源也尽量内联（data URI），最终 `dist/` 只剩 `index.html`

## 执行流程（你需要按顺序做）

### 1) 识别构建工具
按优先级判断：
1. Vite：存在 `vite.config.*` 或 `package.json` scripts 里有 `vite build`
2. Webpack：存在 `webpack.config.*`
3. Next.js：存在 `next.config.*`
4. 其他：先走“后处理脚本方案”

如果是 Vite（推荐优先实现）
### 2) Vite 方案（优先：插件内联）
1. 安装单文件插件（优先 `vite-plugin-singlefile`；仓库若已有同类插件则复用）
2. 在 `vite.config.*` 接入插件，并确保尽量减少多文件产物：
   - 关闭 CSS 拆分：`build.cssCodeSplit = false`
   - 尽量避免多 chunk：合并动态导入 / 关闭手动分包（基于当前配置风格做最小改动）
   - 提高资源内联阈值：`build.assetsInlineLimit`（严格单文件可设置很大；宽松模式保持默认或中等）
3. 在 `package.json` 新增脚本（不要破坏原有 `build`）：
   - `build:single`: 生成单文件发布产物
4. 产物检查：
   - `dist/index.html` 内应包含内联 `<style>` 与 `<script>`（或等效内联）
   - 严格模式下 `dist/` 不应残留 `assets/`（若残留则进入“后处理兜底”）

### 3) 后处理兜底方案（适用于：严格单文件、或非 Vite）
1. 保持原构建：先运行正常 build 生成 `dist/`
2. 新增 Node 脚本（例如 `scripts/inline-dist.mjs`）做这些事：
   - 读取 `dist/index.html`
   - 把 `<link rel="stylesheet" href="...">` 对应 CSS 文件内容内联成 `<style>`
   - 把 `<script type="module" src="...">` 对应 JS 文件内容内联成 `<script>`
   - 可选：把 `<img src>`、CSS `url(...)` 指向的资源读出来转为 data URI
   - 可选：清理 `dist/assets/`，最终只保留 `dist/index.html`
3. 在 `package.json` 新增脚本：
   - `build:single`: `build && node scripts/inline-dist.mjs`

## 常见注意事项
- 单文件会明显变大，且失去浏览器对 `assets/*.js` 的长期缓存优势；适合演示/交付单文件场景。
- 如果页面依赖 Service Worker、Web Worker、或大量静态资源，严格单文件可能需要额外处理（优先走“后处理兜底方案”）。

## 输出说明（执行结束必须汇报）
- 使用的方案（Vite 插件 / 后处理脚本）
- 新增/修改了哪些脚本（例如 `build:single`）
- 运行构建后的产物情况（`dist/` 里有哪些文件）
